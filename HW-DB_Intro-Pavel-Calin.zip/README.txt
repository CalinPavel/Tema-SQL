		--- Tema2 ---
		 Pavel Calin


Implementare:
	-cheile primare le am setat ca uuid
	-pentru verificarea limitei impuse intre tabelul
	profesor si cel student am creat un trigger specific
	-am respectat tipul relatilor prezentate in desenul 
	initial
	-am creat un tabel aditional pentru relatia ManyToMany
	dintre profesor si student
	-la finalul fisierului de script-uri am testat si trigger-ul
	adaugat in sursa de baza

Am adaugat in arhiva si .txt cu DB + queries.